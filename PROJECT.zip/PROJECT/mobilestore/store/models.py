from django.db import models
from account.models import CustUser
# Create your models here.
class Products(models.Model):
    item=models.CharField(max_length=100)
    category=models.CharField(max_length=100)
    price=models.IntegerField()
    store=models.ForeignKey(CustUser, on_delete=models.CASCADE,related_name="st_product",null=True)