from django.urls import path
from .views import CustHome


urlpatterns = [
    path('custh/',CustHome.as_view(),name="custhome"),
    
]
