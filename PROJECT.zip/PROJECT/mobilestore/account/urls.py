from django.urls import path
from.views import RegView

urlpatterns = [
    path("regi/",RegView.as_view(),name="reg")
]
